# QuizQuest
Third Brief For Orange Coding Academy, This is a quiz website designed to test the front-end knowledge for companies wanting to test new hires programming knowledge, or just a test for any programmer that want to strenghthen his knowledge
